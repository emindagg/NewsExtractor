import os
import logging
from flask import Flask, render_template, request, jsonify, send_file
from io import StringIO
import urllib.parse
import tempfile
from utils.scraper import extract_news_content

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

@app.route('/')
def index():
    """Render the main page with the URL input form."""
    return render_template('index.html')

@app.route('/extract', methods=['POST'])
def extract():
    """Extract content from the provided URL."""
    try:
        url = request.form.get('url', '')
        
        # Validate URL
        if not url:
            return jsonify({'error': 'URL gereklidir'}), 400
        
        # Check if URL is valid
        parsed_url = urllib.parse.urlparse(url)
        if not parsed_url.scheme or not parsed_url.netloc:
            return jsonify({'error': 'Geçersiz URL. Lütfen http:// veya https:// ile başlayan geçerli bir URL giriniz.'}), 400
        
        # Extract content
        content = extract_news_content(url)
        
        # Check if content is an error message (our custom error messages from scraper.py)
        if content.startswith("Hata oluştu:") or content.startswith("İçerik çıkarılamadı") or content.startswith("URL format hatası") or content.startswith("İçerik indirilemedi"):
            return jsonify({'error': content}), 400
            
        return jsonify({'content': content})
    
    except Exception as e:
        app.logger.error(f"İçerik çıkarılırken hata oluştu: {str(e)}")
        return jsonify({'error': f'İçerik çıkarılırken hata oluştu: {str(e)}'}), 500

@app.route('/download', methods=['POST'])
def download():
    """Download the extracted content as a text file."""
    try:
        content = request.form.get('content', '')
        title = request.form.get('title', 'news_article')
        
        # Sanitize filename
        title = "".join([c for c in title if c.isalpha() or c.isdigit() or c==' ']).rstrip()
        if not title:
            title = 'news_article'
            
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.txt') as temp:
            temp.write(content)
            temp_path = temp.name
            
        return send_file(
            temp_path,
            as_attachment=True,
            download_name=f"{title}.txt",
            mimetype='text/plain'
        )
    
    except Exception as e:
        app.logger.error(f"Error downloading content: {str(e)}")
        return jsonify({'error': f'Error downloading content: {str(e)}'}), 500

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html', error="Sayfa bulunamadı"), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('index.html', error="Sunucu hatası"), 500
