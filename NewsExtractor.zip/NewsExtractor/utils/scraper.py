import trafilatura
import logging
from urllib.parse import urlparse

def extract_news_content(url: str) -> str:
    """
    Extract and clean news content from a given URL.
    
    Args:
        url (str): The URL of the news article to extract content from
        
    Returns:
        str: The cleaned news content
    """
    logging.debug(f"Extracting content from URL: {url}")
    
    try:
        # Validate URL format
        parsed_url = urlparse(url)
        if not parsed_url.scheme or not parsed_url.netloc:
            logging.error(f"Invalid URL format: {url}")
            return "URL format hatası. Lütfen geçerli bir haber linki giriniz."
        
        # Check for gallery URLs which need special handling
        is_gallery = False
        if '/galeri/' in url.lower() or 'gallery' in url.lower():
            logging.info(f"Detected gallery URL: {url}")
            is_gallery = True
        
        # Download the webpage content
        downloaded = trafilatura.fetch_url(url)
        if not downloaded:
            logging.error(f"Failed to download content from URL: {url}")
            return "İçerik indirilemedi. Site erişime kapalı olabilir veya robot engeli olabilir."
        
        # Extract the main content using trafilatura with special handling for gallery pages
        try:
            content = trafilatura.extract(
                downloaded,
                include_comments=False,
                include_tables=True,
                include_links=False,
                include_images=is_gallery,  # Include images for gallery pages
                output_format='txt'
            )
        except Exception as extract_error:
            logging.error(f"Error during extraction process: {str(extract_error)}")
            # Try alternative extraction with different settings
            try:
                content = trafilatura.extract(
                    downloaded,
                    include_comments=False,
                    include_tables=True,
                    include_links=False,
                    include_images=False,
                    output_format='txt'
                )
            except Exception as fallback_error:
                logging.error(f"Fallback extraction also failed: {str(fallback_error)}")
                if is_gallery:
                    return "Galeri sayfası içeriği çıkarılamadı. Bu tür içerikler henüz tam desteklenmiyor."
                return "İçerik çıkarılamadı. Bu siteden içerik çekilemiyor olabilir. Lütfen başka bir haber URL'si deneyin."
        
        if not content:
            logging.error(f"Failed to extract readable content from URL: {url}")
            if is_gallery:
                return "Galeri sayfası içeriği çıkarılamadı. Bu tür içerikler henüz tam desteklenmiyor."
            return "İçerik çıkarılamadı. Bu siteden içerik çekilemiyor olabilir. Lütfen başka bir haber URL'si deneyin."
            
        return content
        
    except Exception as e:
        logging.error(f"Error extracting content: {str(e)}")
        return f"Hata oluştu: {str(e)}"
