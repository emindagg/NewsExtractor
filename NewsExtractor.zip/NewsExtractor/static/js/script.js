document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const urlForm = document.getElementById('url-form');
    const newsUrlInput = document.getElementById('news-url');
    const extractBtn = document.getElementById('extract-btn');
    const downloadBtn = document.getElementById('download-btn');
    const loadingIndicator = document.getElementById('loading');
    const errorAlert = document.getElementById('error-alert');
    const errorMessage = document.getElementById('error-message');
    const resultsContainer = document.getElementById('results-container');
    const contentDisplay = document.getElementById('content-display');
    const exampleUrls = document.querySelectorAll('.example-url');
    
    // Store the extracted content
    let extractedContent = '';
    let articleTitle = 'news_article';
    
    // Example URL click handler
    exampleUrls.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            newsUrlInput.value = this.textContent;
        });
    });
    
    // Handle form submission
    urlForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const url = newsUrlInput.value.trim();
        
        // Validate URL format
        if (!isValidUrl(url)) {
            showError('Lütfen geçerli bir URL girin (http:// veya https:// ile başlamalı)');
            return;
        }
        
        // Reset UI
        hideError();
        hideResults();
        showLoading();
        
        // Disable extract button while processing
        extractBtn.disabled = true;
        
        // Create form data
        const formData = new FormData();
        formData.append('url', url);
        
        // Send extraction request to server
        fetch('/extract', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP Hata: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            hideLoading();
            extractBtn.disabled = false;
            
            if (data.error) {
                showError(data.error);
                return;
            }
            
            if (!data.content) {
                showError('İçerik çıkarılamadı. Lütfen başka bir URL deneyin.');
                return;
            }
            
            // Store content for downloading
            extractedContent = data.content;
            
            // Try to extract a title from the URL
            try {
                const urlObj = new URL(url);
                const pathSegments = urlObj.pathname.split('/').filter(segment => segment.length > 0);
                if (pathSegments.length > 0) {
                    articleTitle = pathSegments[pathSegments.length - 1].replace(/[^a-zA-Z0-9]/g, '_');
                } else {
                    articleTitle = urlObj.hostname.replace('www.', '');
                }
            } catch (e) {
                articleTitle = 'news_article';
            }
            
            // Display content
            displayContent(data.content);
        })
        .catch(error => {
            console.error('Error:', error);
            hideLoading();
            extractBtn.disabled = false;
            showError('Bir hata oluştu: ' + error.message);
        });
    });
    
    // Handle download button click
    downloadBtn.addEventListener('click', function() {
        if (!extractedContent) {
            showError('İndirilecek içerik bulunamadı.');
            return;
        }
        
        // Create form for download
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/download';
        
        // Add content to form
        const contentField = document.createElement('input');
        contentField.type = 'hidden';
        contentField.name = 'content';
        contentField.value = extractedContent;
        form.appendChild(contentField);
        
        // Add title to form
        const titleField = document.createElement('input');
        titleField.type = 'hidden';
        titleField.name = 'title';
        titleField.value = articleTitle;
        form.appendChild(titleField);
        
        // Submit form to download file
        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    });
    
    // Helper functions
    function isValidUrl(url) {
        try {
            const parsedUrl = new URL(url);
            return ['http:', 'https:'].includes(parsedUrl.protocol);
        } catch (e) {
            return false;
        }
    }
    
    function showLoading() {
        loadingIndicator.classList.remove('d-none');
    }
    
    function hideLoading() {
        loadingIndicator.classList.add('d-none');
    }
    
    function showError(message) {
        errorMessage.textContent = message;
        errorAlert.classList.remove('d-none');
    }
    
    function hideError() {
        errorAlert.classList.add('d-none');
    }
    
    function hideResults() {
        resultsContainer.classList.add('d-none');
    }
    
    function displayContent(content) {
        // Format the content for display
        const formattedContent = content
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0)
            .map(line => `<p>${line}</p>`)
            .join('');
        
        contentDisplay.innerHTML = formattedContent;
        resultsContainer.classList.remove('d-none');
        
        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }
});
